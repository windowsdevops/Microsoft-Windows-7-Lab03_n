
#undef _CRTIMP
#define _CRTIMP
#include <yvals.h>
#undef _CRTIMP
#define _CRTIMP __declspec(dllimport)

#include <windows.h>
