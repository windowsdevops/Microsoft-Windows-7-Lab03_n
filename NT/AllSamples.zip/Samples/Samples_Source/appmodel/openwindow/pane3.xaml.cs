using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OpenWindow
{
    /// <summary>
    /// Interaction logic for Pane3.xaml
    /// </summary>

    public partial class Pane3 : DockPanel
    {
        // The OnLoaded handler can be run automatically when the class is loaded. To use it, add Loaded="OnLoaded" to the attributes of the root element of the .xaml file and uncomment the following line.
        // private void OnLoaded(object sender, EventArgs e) {}
        // Sample event handler:  
        // private void ButtonClick(object sender, ClickEventArgs e) {}

    }
}