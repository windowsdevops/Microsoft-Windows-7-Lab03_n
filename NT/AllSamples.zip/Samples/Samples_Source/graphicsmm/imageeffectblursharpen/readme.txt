NOTE: This sample was first written on my spare time for my blog using the PDC build of Longhorn.
      It has since been modified to work with the latest builds.