using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace UsingImageBrush
{
    /// <summary>
    /// Interaction logic for BasicImageFills.xaml
    /// </summary>

    public partial class BasicImageFills : GridPanel
    {
        // The OnLoaded handler can be run automatically when the class is loaded. To use it, add Loaded="OnLoaded" to the attributes of the root element of the .xaml file and uncomment the following line.
        // private void OnLoaded(object sender, EventArgs e) {}
        // Sample event handler:  
        // private void ButtonClick(object sender, ClickEventArgs e) {}

    }
}