//This is a list of commonly used namespaces for a window.
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Data;
using System.Windows.Media;

namespace UsingImageBrush
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>

    public partial class MyWindow : Window
    {
       
       

    }
}