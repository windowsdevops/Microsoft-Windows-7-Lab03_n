// This file includes all the generated class implementations for compilation

#include "stdafx.h"

#define _ASCPP
#include "MyApp.g.cpp"			// Implements the base application object
#include "MainWindow.g.cpp" 	// Implements the base window object

// TODO: add additional #includes for xaml file outputs here
//       the convention is <xaml file name>.g.cpp.

#include "animateproperty_mcpp.Main.g.cpp"	// Implements the entry point and resource loader
#undef _ASCPP
