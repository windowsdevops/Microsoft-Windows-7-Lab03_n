
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Data;

namespace restartanimation_markup_using_id_csharp
{
    /// <summary>
    /// See Window1.xaml for the markup and code that demonstrates how to control
    /// an animation interactively.
    /// </summary>

    public partial class Window1 : Window
    {
       

    }
}