namespace WCPSample {
	public class SimpleBinding {
			private string _simpleProperty = "This is a string from the data source";
			public string SimpleProperty
			{
				get
				{
					return _simpleProperty;
				}
			}
		public SimpleBinding()	{}
    }
}