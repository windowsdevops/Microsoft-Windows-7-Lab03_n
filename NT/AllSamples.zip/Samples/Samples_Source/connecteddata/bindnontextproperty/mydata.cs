using System.Windows.Media;
using System;

namespace WCPSample {
	public class myData {
		static string _data = "Red";
		public string BoundColor
		{
			get
			{
				return _data;
			}
		}
    }
}